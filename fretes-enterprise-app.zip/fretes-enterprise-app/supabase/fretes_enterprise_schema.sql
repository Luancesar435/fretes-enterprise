-- FRETES ENTERPRISE • SUPABASE SQL DEFINITIVO
-- Execute este arquivo no SQL Editor do Supabase.

create extension if not exists pgcrypto;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  cnpj text,
  status text not null default 'active' check (status in ('active', 'inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text not null default 'member' check (role in ('owner', 'admin', 'manager', 'analyst', 'member')),
  company_id uuid references public.companies(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.transportadoras (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  nome text not null,
  tipo_cobranca_padrao text,
  observacoes text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(company_id, nome)
);

create table if not exists public.marketplaces (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  nome text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(company_id, nome)
);

create table if not exists public.import_runs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  source_filename text not null,
  source_hash text,
  status text not null default 'processed' check (status in ('uploaded', 'processing', 'processed', 'failed')),
  row_count integer not null default 0,
  summary jsonb not null default '{}'::jsonb,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  import_run_id uuid references public.import_runs(id) on delete set null,
  order_code text,
  transportadora text,
  tipo_cobranca text,
  marketplace text,
  uf_destino text,
  cidade_destino text,
  operation_type text not null default 'Envio' check (operation_type in ('Envio', 'Devolução', 'Reentrega')),
  amount_carrier numeric(14,2) not null default 0,
  amount_customer numeric(14,2) not null default 0,
  amount_table numeric(14,2) not null default 0,
  amount_divergence numeric(14,2) not null default 0,
  result_amount numeric(14,2) generated always as (amount_customer - amount_carrier) stored,
  margin_percent numeric(10,2) generated always as (
    case when amount_customer > 0 then ((amount_customer - amount_carrier) / amount_customer) * 100 else -100 end
  ) stored,
  is_invalid boolean generated always as (
    marketplace in ('0', '#N/A', 'Não informado') or uf_destino = '#N/A'
  ) stored,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.freight_pricing_rules (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  transportadora_id uuid references public.transportadoras(id) on delete set null,
  marketplace_id uuid references public.marketplaces(id) on delete set null,
  uf_destino text,
  faixa_cep_inicial text,
  faixa_cep_final text,
  peso_min_kg numeric(10,3),
  peso_max_kg numeric(10,3),
  cubagem_min numeric(10,3),
  cubagem_max numeric(10,3),
  tariff_amount numeric(14,2) not null default 0,
  ad_valorem_percent numeric(10,4) not null default 0,
  gris_amount numeric(14,2) not null default 0,
  toll_amount numeric(14,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.monthly_snapshots (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  reference_year integer not null,
  reference_month integer not null check (reference_month between 1 and 12),
  receita numeric(14,2) not null default 0,
  custo numeric(14,2) not null default 0,
  resultado numeric(14,2) not null default 0,
  margem_percent numeric(10,2) not null default 0,
  pedidos integer not null default 0,
  pedidos_prejuizo integer not null default 0,
  devolucoes_custo numeric(14,2) not null default 0,
  reentregas_custo numeric(14,2) not null default 0,
  divergencia_total numeric(14,2) not null default 0,
  invalidos integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(company_id, reference_year, reference_month)
);

create index if not exists idx_shipments_company on public.shipments(company_id);
create index if not exists idx_shipments_import_run on public.shipments(import_run_id);
create index if not exists idx_shipments_transportadora on public.shipments(company_id, transportadora);
create index if not exists idx_shipments_marketplace on public.shipments(company_id, marketplace);
create index if not exists idx_shipments_uf on public.shipments(company_id, uf_destino);
create index if not exists idx_shipments_operation on public.shipments(company_id, operation_type);
create index if not exists idx_import_runs_company on public.import_runs(company_id);
create index if not exists idx_profiles_company on public.profiles(company_id);

create trigger trg_companies_updated_at before update on public.companies for each row execute function public.set_updated_at();
create trigger trg_profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger trg_transportadoras_updated_at before update on public.transportadoras for each row execute function public.set_updated_at();
create trigger trg_marketplaces_updated_at before update on public.marketplaces for each row execute function public.set_updated_at();
create trigger trg_import_runs_updated_at before update on public.import_runs for each row execute function public.set_updated_at();
create trigger trg_shipments_updated_at before update on public.shipments for each row execute function public.set_updated_at();
create trigger trg_freight_pricing_rules_updated_at before update on public.freight_pricing_rules for each row execute function public.set_updated_at();
create trigger trg_monthly_snapshots_updated_at before update on public.monthly_snapshots for each row execute function public.set_updated_at();

alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.transportadoras enable row level security;
alter table public.marketplaces enable row level security;
alter table public.import_runs enable row level security;
alter table public.shipments enable row level security;
alter table public.freight_pricing_rules enable row level security;
alter table public.monthly_snapshots enable row level security;

create or replace function public.current_company_id()
returns uuid
language sql
stable
as $$
  select company_id from public.profiles where id = auth.uid()
$$;

create policy "profiles_select_own" on public.profiles
for select using (id = auth.uid());

create policy "profiles_update_own" on public.profiles
for update using (id = auth.uid());

create policy "companies_select_own" on public.companies
for select using (id = public.current_company_id());

create policy "transportadoras_company_access" on public.transportadoras
for all using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

create policy "marketplaces_company_access" on public.marketplaces
for all using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

create policy "import_runs_company_access" on public.import_runs
for all using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

create policy "shipments_company_access" on public.shipments
for all using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

create policy "freight_pricing_rules_company_access" on public.freight_pricing_rules
for all using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

create policy "monthly_snapshots_company_access" on public.monthly_snapshots
for all using (company_id = public.current_company_id()) with check (company_id = public.current_company_id());

create or replace view public.v_logistics_summary as
select
  company_id,
  count(*) as pedidos,
  sum(amount_customer) as receita,
  sum(amount_carrier) as custo,
  sum(result_amount) as resultado,
  case when sum(amount_customer) > 0 then round((sum(result_amount) / sum(amount_customer)) * 100, 2) else 0 end as margem_percent,
  sum(case when result_amount < 0 then 1 else 0 end) as pedidos_prejuizo,
  sum(case when operation_type = 'Devolução' then amount_carrier else 0 end) as devolucoes_custo,
  sum(case when operation_type = 'Reentrega' then amount_carrier else 0 end) as reentregas_custo,
  sum(amount_divergence) as divergencia_total,
  sum(case when is_invalid then 1 else 0 end) as invalidos
from public.shipments
group by company_id;

insert into public.companies (name, slug, cnpj)
values ('Empresa Demo', 'empresa-demo', '00.000.000/0001-00')
on conflict (slug) do nothing;
